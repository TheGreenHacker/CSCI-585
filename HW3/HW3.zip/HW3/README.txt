# CSCI 585 HW3
NAME: Jack Li
ID: 1321-1056-14

## Q6
Jsfiddle link: http://jsfiddle.net/7c6hboe5/35/

